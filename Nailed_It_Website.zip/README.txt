NAILED IT WEBSITE

Open index.html in a browser to preview the website.

To publish it for free, upload index.html to a free static hosting service such as GitHub Pages, Netlify, or Cloudflare Pages. A custom .co.uk domain normally requires registration/payment.

Contact details included:
Phone: 07359 446 074
Email: nailedit.thehandyman@outlook.com
Facebook: @NailedItHandyman
